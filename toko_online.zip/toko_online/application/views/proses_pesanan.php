<div class="container-fluid">
    <div class="alert alert-success" role="alert">
        <h4 class="text-center align-middle alert-heading">
        Pesanan Anda berhasil di proses!</h4>
    </div>
</div>