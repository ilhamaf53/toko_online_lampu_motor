<?php

class Kategori extends CI_Controller{
    public function lampu_proled() {
            $data['lampu_proled'] = $this->model_kategori->data_lampu_proled()->result();
            $this->load->view('templates/header');
            $this->load->view('templates/sidebar');
            $this->load->view('lampu_proled',$data);
            $this->load->view('templates/footer');
    }

    public function lampu_propajero() {
        $data['lampu_propajero'] = $this->model_kategori->data_lampu_propajero()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('lampu_propajero',$data);
        $this->load->view('templates/footer');
    }

    public function lampu_prohid() {
        $data['lampu_prohid'] = $this->model_kategori->data_lampu_prohid()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('lampu_prohid',$data);
        $this->load->view('templates/footer');
    }

    public function lampu_led_standar() {
        $data['lampu_led_standar'] = $this->model_kategori->data_lampu_led_standar()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('lampu_led_standar',$data);
        $this->load->view('templates/footer');
    }
}   