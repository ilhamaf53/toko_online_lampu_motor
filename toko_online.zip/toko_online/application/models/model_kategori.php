<?php

class Model_kategori extends CI_Model {
    public function data_lampu_proled() {
        return $this->db->get_where("tb_barang",array(
            'kategori' => 'lampu_proled'
        ));
    }

    public function data_lampu_propajero() {
        return $this->db->get_where("tb_barang",array(
            'kategori' => 'lampu_propajero'
        ));
    }

    public function data_lampu_prohid() {
        return $this->db->get_where("tb_barang",array(
            'kategori' => 'lampu_prohid'
        ));
    }

    public function data_lampu_led_standar() {
        return $this->db->get_where("tb_barang",array(
            'kategori' => 'lampu_led_standar'
        ));
    }
}